#pragma once

#include <string>

struct AppConfig {
    std::string room;
    std::string participantFilter;
    std::string ndiName = "JitsiNativeNDI";
    std::string nick = "probe123";

    int width = 1280;
    int height = 720;
    int fps = 30;

    bool realXmpp = true;
    std::string websocketUrl = "https://meet.jit.si/xmpp-websocket";
    std::string domain = "meet.jit.si";
    std::string guestDomain = "guest.meet.jit.si";
    std::string mucDomain = "conference.meet.jit.si";
    bool guestMode = true;
    bool addRoomAndTokenToWebSocketUrl = true;

    std::string authMode = "anonymous";
    std::string authUser;
    std::string authPassword;
    std::string authToken;
};

AppConfig parseArgs(int argc, char** argv);
void printUsage();
