$ErrorActionPreference = 'Stop'
$patchDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $patchDir

$files = @(
    'src\NativeWebRTCAnswerer.cpp',
    'src\JitsiSourceMap.cpp',
    'src\JitsiSourceMap.h',
    'src\PerParticipantNdiRouter.cpp',
    'src\PerParticipantNdiRouter.h'
)

foreach ($rel in $files) {
    $dst = Join-Path $root $rel
    $dir = Split-Path -Parent $dst
    $name = Split-Path -Leaf $dst
    $backup = Get-ChildItem -Path $dir -Filter ($name + '.bak_v43_*') | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $backup) { throw "Backup not found for $rel" }
    Copy-Item -Force $backup.FullName $dst
    Write-Host "Restored $rel from $($backup.Name)"
}

Write-Host "v43 backup restored. Rebuild the native exe now."
