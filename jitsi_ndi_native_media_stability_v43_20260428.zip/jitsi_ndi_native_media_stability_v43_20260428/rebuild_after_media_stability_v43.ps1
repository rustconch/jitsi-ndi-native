$ErrorActionPreference = 'Stop'
$patchDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $patchDir
Set-Location $root

if (Test-Path '.\rebuild_with_dav1d_v21.ps1') {
    .\rebuild_with_dav1d_v21.ps1
} elseif (Test-Path '.\build-ndi') {
    cmake --build .\build-ndi --config Release
} else {
    throw 'No known rebuild script/build directory found. Run your normal Release rebuild manually.'
}
