$ErrorActionPreference = 'Stop'

$patchDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $patchDir
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'

$files = @(
    'src\NativeWebRTCAnswerer.cpp',
    'src\JitsiSourceMap.cpp',
    'src\JitsiSourceMap.h',
    'src\PerParticipantNdiRouter.cpp',
    'src\PerParticipantNdiRouter.h'
)

foreach ($rel in $files) {
    $src = Join-Path $patchDir $rel
    $dst = Join-Path $root $rel
    if (-not (Test-Path $src)) { throw "Patch file not found: $src" }
    if (-not (Test-Path $dst)) { throw "Target file not found: $dst" }
    Copy-Item -Force $dst ($dst + ".bak_v43_" + $stamp)
    Copy-Item -Force $src $dst
    Write-Host "Patched $rel"
}

Write-Host "v43 media stability patch applied. Rebuild the native exe now."
