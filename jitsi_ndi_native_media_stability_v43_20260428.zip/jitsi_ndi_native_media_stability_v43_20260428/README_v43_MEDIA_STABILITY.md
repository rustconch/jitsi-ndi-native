# v43 media stability patch

This patch is built on top of the stable selected-only v42 quality mode.
It does not touch GUI files.

Changes:

1. Audio subscription is changed from `ReceiverAudioSubscription mode=All` to `mode=Include` with only real endpoint audio sources such as `endpoint-a0`.
2. The bridge/mixed placeholder audio source `jvb-a0` is filtered out in the router even if JVB still forwards it.
3. Jitsi FID groups are parsed. The first SSRC stays as primary media; following SSRCs are marked as RTX/retransmission.
4. RTX video SSRCs are dropped before they can enter the AV1/VP8 assembler. This is meant to reduce frozen/corrupted screen-share pipelines.
5. Video quality mode remains v42: selected-only, 1080p/30, lastN=-1, no all-on-stage, no repeated refresh loops.

Apply:

```powershell
cd D:\MEDIA\Desktop\jitsi-ndi-native
Expand-Archive -Force .\jitsi_ndi_native_media_stability_v43_20260428.zip .
.\jitsi_ndi_native_media_stability_v43_20260428\apply_media_stability_v43.ps1
.\rebuild_with_dav1d_v21.ps1
```

Expected log lines:

```text
NativeWebRTCAnswerer: endpoint audio sources extracted from SDP offer:
NativeWebRTCAnswerer: requesting endpoint audio only
ReceiverAudioSubscription/Include-endpoint-audio/open
NativeWebRTCAnswerer: v43 stable media mode; selected-only video; endpoint-only audio; RTX video SSRCs dropped in router
PerParticipantNdiRouter: dropping JVB/mixed placeholder audio
PerParticipantNdiRouter: dropping RTX/retransmission video RTP
```

Rollback:

```powershell
.\jitsi_ndi_native_media_stability_v43_20260428\restore_latest_media_stability_v43_backup.ps1
.\rebuild_with_dav1d_v21.ps1
```
